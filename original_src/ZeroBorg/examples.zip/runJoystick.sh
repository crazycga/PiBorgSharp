#!/bin/bash
/home/pi/zeroborg/zbJoystick.py > /dev/null

