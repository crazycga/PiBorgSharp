#!/bin/bash
/home/pi/zeroborg/zbMecanumJoy.py > /dev/null

